package com.example.myapplication;

public class Cl {
    private int sum=0;
    private int sum1=1;
    private int sum2=2;
    public Cl() {

    }
    public void one(){}
    public void two(){}
    public void three(){}
}
