package com.example.myapplication;

public interface ICallBack<T,M> {
    void onSuccess(T t);
}
