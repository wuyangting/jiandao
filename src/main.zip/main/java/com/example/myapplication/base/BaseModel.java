package com.example.myapplication.base;

public class BaseModel {

}
