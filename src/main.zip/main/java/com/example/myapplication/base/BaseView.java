package com.example.myapplication.base;

public interface BaseView {
    //继承：一个类获取一个类属性的一个过程
    void showToast(String msg);
}
