package com.example.myapplication.home.bean;

public class User {
}
