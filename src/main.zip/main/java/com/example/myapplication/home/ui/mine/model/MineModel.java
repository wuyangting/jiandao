package com.example.myapplication.home.ui.mine.model;

import com.example.myapplication.base.BaseModel;
import com.example.myapplication.home.contract.HomeContract;
import com.example.myapplication.home.ui.special.contract.SpecialContract;
import com.example.myapplication.net.INetCallback;

public class MineModel extends BaseModel implements HomeContract.MainModel {
    @Override
    public <T> void getData(INetCallback<T> netCallback) {

    }
}
