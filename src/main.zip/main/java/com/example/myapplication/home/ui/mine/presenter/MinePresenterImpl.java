package com.example.myapplication.home.ui.mine.presenter;

import com.example.myapplication.base.BasePre;
import com.example.myapplication.home.contract.HomeContract;
import com.example.myapplication.home.ui.mine.contract.MineContract;
import com.example.myapplication.home.ui.special.contract.SpecialContract;

public class MinePresenterImpl extends BasePre<MineContract.MineView> implements MineContract.MinePre {

    @Override
    public void getData() {

    }

    @Override
    public void callMineData(String string) {

    }
}
