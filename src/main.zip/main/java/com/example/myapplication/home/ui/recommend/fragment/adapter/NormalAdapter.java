package com.example.myapplication.home.ui.recommend.fragment.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.myapplication.R;
import com.example.myapplication.home.ui.recommend.fragment.bean.RecommendRecBean;
import com.youth.banner.Banner;
import com.youth.banner.loader.ImageLoader;

import java.util.ArrayList;
import java.util.List;

public class NormalAdapter extends RecyclerView.Adapter {
    private ArrayList<RecommendRecBean.DataBean.BannerListBean> data=new ArrayList<>();
    private Context context;

    public NormalAdapter(Context context) {
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View inflate = LayoutInflater.from(context).inflate(R.layout.banner, parent, false);
        return new BannerViewHolder(inflate);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        BannerViewHolder bannerViewHolder= (BannerViewHolder) holder;
        bannerViewHolder.banner.setImages(data).setImageLoader(new ImageLoader() {
            @Override
            public void displayImage(Context context, Object path, ImageView imageView) {
                RecommendRecBean.DataBean.BannerListBean image= (RecommendRecBean.DataBean.BannerListBean) path;
                Glide.with(context).load(image.getImage_url()).into(imageView);
            }
        }).start();
    }

    @Override
    public int getItemCount() {
        return 1;
    }

    public void addData(RecommendRecBean data2) {
        RecommendRecBean.DataBean data = data2.getData();
        this.data.addAll(data2.getData().getBanner_list());
        notifyDataSetChanged();
    }

    class BannerViewHolder extends RecyclerView.ViewHolder {
        Banner banner;
        public BannerViewHolder(@NonNull View itemView) {
            super(itemView);
            banner=itemView.findViewById(R.id.banner);
        }
    }
}
