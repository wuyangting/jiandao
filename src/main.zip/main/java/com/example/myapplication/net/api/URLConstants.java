package com.example.myapplication.net.api;

public class URLConstants {
public static String BASE_URL="https://www.seetao.com/";
    //推荐列表
   public static String RECOMMEND_LIST= "app/v_1_3/article/recommendlist";


//  视频列表
    public static  String VEDIO_LIST = "app/v_1_3/article/videolist";
}
